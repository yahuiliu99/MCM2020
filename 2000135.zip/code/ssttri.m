clear
load seagrid6064.mat
load seagrid6569.mat
load seagrid7074.mat
load seagrid7579.mat
load seagrid8084.mat
load seagrid8589.mat
load seagrid9094.mat
load seagrid9599.mat
load seagrid0004.mat
load seagrid0508.mat
load seagrid1214.mat
seatrix=zeros(391,11);
seatrix(:,1)=seagrid6064(:);
seatrix(:,2)=seagrid6569(:);
seatrix(:,3)=seagrid7074(:);
seatrix(:,4)=seagrid7579(:);
seatrix(:,5)=seagrid8084(:);
seatrix(:,6)=seagrid8589(:);
seatrix(:,7)=seagrid9094(:);
seatrix(:,8)=seagrid9599(:);
seatrix(:,9)=seagrid0004(:);
seatrix(:,10)=seagrid0508(:);
seatrix(:,11)=seagrid1214(:);
