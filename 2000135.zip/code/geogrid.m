clc
clear

geodensityplot(54,8,0);
geobasemap grayland